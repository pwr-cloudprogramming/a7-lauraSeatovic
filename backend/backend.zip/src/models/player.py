class Player():
    def __init__(self, symbol, playerId, name):
        self.symbol = symbol
        self.playerId = playerId
        self.name = name